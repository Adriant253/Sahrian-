<?php
include 'db_connection.php';

if ($conn) {
    echo "Conexión exitosa a la base de datos";
}
?>
